// import React, { useState } from 'react';
// import Calculator from './Calculator';
// import Checklist from './Checklist';

// function Tools() {
//   const [tool, setTool] = useState('calculator');

//   return (
//     <div>
//       <h1>Tools</h1>
//       <div>
//         <button onClick={() => setTool('calculator')}>Calculator</button>
//         <button onClick={() => setTool('checklist')}>Checklist</button>
//       </div>
//       {tool === 'calculator' && <Calculator />}
//       {tool === 'checklist' && <Checklist />}
//     </div>
//   );
// }

// export default Tools;

import React, { useState } from 'react';
import Calculator from './Calculator';
import Checklist from './Checklist';

function Tools() {
  const [tool, setTool] = useState('calculator');

  const buttonStyle = {
    background: '#5c5c5c',
    color: '#fff',
    padding: '10px',
    border: 'none',
    borderRadius: '5px',
    margin: '5px',
    cursor: 'pointer',
  };

  return (
    <div style={{ textAlign: 'center', margin: '20px' }}>
      <h1 style={{ fontSize: '36px', marginBottom: '30px' }}>Tools</h1>
      <div>
        <button
          style={tool === 'calculator' ? { ...buttonStyle, background: '#2d2d2d' } : buttonStyle}
          onClick={() => setTool('calculator')}
        >
          Calculator
        </button>
        <button
          style={tool === 'checklist' ? { ...buttonStyle, background: '#2d2d2d' } : buttonStyle}
          onClick={() => setTool('checklist')}
        >
          Checklist
        </button>
      </div>
      <div style={{ marginTop: '30px' }}>
        {tool === 'calculator' && <Calculator />}
        {tool === 'checklist' && <Checklist />}
      </div>
    </div>
  );
}

export default Tools;
