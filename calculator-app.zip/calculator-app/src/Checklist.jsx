import React, { useState } from 'react';
import './App.css';

export default function Checklist() {
  const [newItemText, setNewItemText] = useState('');
  const [items, setItems] = useState([]);

  const handleNewItemTextChange = (event) => {
    setNewItemText(event.target.value);
  };

  const handleAddItemClick = () => {
    if (newItemText.trim() !== '') {
      setItems([...items, newItemText.trim()]);
      setNewItemText('');
    }
  };

  const handleDeleteItemClick = (index) => {
    const newItems = [...items];
    newItems.splice(index, 1);
    setItems(newItems);
  };

  return (
    <div className="checklist-container">
      <h2>Checklist</h2>
      <div className="checklist-form">
        <input
          type="text text-center"
          placeholder="Add new item"
          value={newItemText}
          onChange={handleNewItemTextChange}
        />
        <button className="checklist-add-button" onClick={handleAddItemClick}>
          Add
        </button>
      </div>
      {items.length > 0 ? (
        <ul className="checklist-items">
          {items.map((item, index) => (
            <li key={index}>
              <span>{item}</span>
              <button className="checklist-delete-button" onClick={() => handleDeleteItemClick(index)}>
                Delete
              </button>
            </li>
          ))}
        </ul>
      ) : (
        <p className="checklist-empty">Your checklist is empty</p>
      )}
    </div>
  );
}
