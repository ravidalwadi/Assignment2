import React from 'react';

function Home() {
  return (
    <div>
      <h1>Home</h1>
      <p>Welcome to our website!</p>
    </div>
  );
}

export default Home;
