// import React from 'react';

// function About() {
//   return (
//     <div>
//       <h1>About</h1>
//       <p>We are a team of developers who love to build awesome software!</p>
//     </div>
//   );
// }

// export default About;

import React from 'react';
import aboutImg from './about1.png';

function About() {
  return (
    <div className="container py-3">
      <header>
        <div className="d-flex flex-column flex-md-row align-items-center pb-3 mb-4 border-bottom">
          <a href="./home.html" className="d-flex align-items-center text-dark text-decoration-none">
            <h5 className="blog-title"> Ravi Dalwadi </h5>
          </a>

          <nav className="d-inline-flex mt-2 mt-md-0 ms-md-auto">
          <a className="me-3 py-2 text-dark text-decoration-none" href="./Home.jsx">Home</a>
            <a className="me-3 py-2 text-dark text-decoration-none" href="./About.jsx">About</a>
            <a className="me-3 py-2 text-dark text-decoration-none" href="./Tools.jsx">Tools</a>
            <a className="me-3 py-2 text-dark text-decoration-none" href="./Services.jsx">Service</a>
          </nav>
        </div>

        <div className="pricing-header p-3 pb-md-4 mx-auto text-center">
          <h1 className="display-4 fw-normal">About</h1>
          <img src={aboutImg} style={{ width: '100%' }} alt="about" />
          <p>We are a team of developers who love to build awesome software!</p>
        </div>
      </header>

      <footer className="pt-4 my-md-5 pt-md-5 border-top">
        <div className="row">
          <div className="col-4 col-md-4">
            <h5>Home</h5>
            <ul className="list-unstyled text-small">
              <li className="mb-1"><a className="link-secondary text-decoration-none" href="#">Basic Information</a></li>
            </ul>
          </div>

          <div className="col-4 col-md-4">
            <h5>Service</h5>
            <ul className="list-unstyled text-small">
              <li className="mb-1"><a className="link-secondary text-decoration-none" href="#">Making Different Websites</a></li>
              <li className="mb-1"><a className="link-secondary text-decoration-none" href="#">Making Different Web Design</a></li>
            </ul>
          </div>

          <div className="col-4 col-md-4">
            <h5>About</h5>
            <ul className="list-unstyled text-small">
              <li className="mb-1"><a className="link-secondary text-decoration-none" href="#">Projects</a></li>
              <li className="mb-1"><a className="link-secondary text-decoration-none" href="#">Contact</a></li>
            </ul>
          </div>
        </div>
      </footer>
    </div>
  );
}

export default About;
