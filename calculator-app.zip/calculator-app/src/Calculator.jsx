// import React, { useState } from 'react';

// // Calculator component
// export default function Calculator() {
//   const [num1, setNum1] = useState('');
//   const [num2, setNum2] = useState('');
//   const [result, setResult] = useState('');

//   const handleNum1Change = (event) => {
//     setNum1(event.target.value);
//   };

//   const handleNum2Change = (event) => {
//     setNum2(event.target.value);
//   };

//   const handleAddClick = () => {
//     const sum = Number(num1) + Number(num2);
//     setResult(`${num1} + ${num2} = ${sum}`);
//   };

//   const handleSubtractClick = () => {
//     const difference = Number(num1) - Number(num2);
//     setResult(`${num1} - ${num2} = ${difference}`);
//   };

//   const handleMultiplyClick = () => {
//     const product = Number(num1) * Number(num2);
//     setResult(`${num1} * ${num2} = ${product}`);
//   };

//   const handleDivideClick = () => {
//     if (Number(num2) === 0) {
//       setResult('Cannot divide by zero');
//     } else {
//       const quotient = Number(num1) / Number(num2);
//       setResult(`${num1} / ${num2} = ${quotient}`);
//     }
//   };

//   return (
//     <div>
//       <h2>Calculator</h2>
//       <label>
//         Number 1:
//         <input type="number" value={num1} onChange={handleNum1Change} />
//       </label>
//       <br />
//       <label>
//         Number 2:
//         <input type="number" value={num2} onChange={handleNum2Change} />
//       </label>
//       <br />
//       <button onClick={handleAddClick}>Add</button>
//       <button onClick={handleSubtractClick}>Subtract</button>
//       <button onClick={handleMultiplyClick}>Multiply</button>
//       <button onClick={handleDivideClick}>Divide</button>
//       <br />
//       <div>Result: {result}</div>
//     </div>
//   );
// }

// export { Calculator };

import React, { useState } from 'react';
import './App.css';

export default function Calculator() {
  const [num1, setNum1] = useState('');
  const [num2, setNum2] = useState('');
  const [result, setResult] = useState('');

  const handleNum1Change = (event) => {
    setNum1(event.target.value);
  };

  const handleNum2Change = (event) => {
    setNum2(event.target.value);
  };

  const handleAddClick = () => {
    const sum = Number(num1) + Number(num2);
    setResult(`${num1} + ${num2} = ${sum}`);
  };

  const handleSubtractClick = () => {
    const difference = Number(num1) - Number(num2);
    setResult(`${num1} - ${num2} = ${difference}`);
  };

  const handleMultiplyClick = () => {
    const product = Number(num1) * Number(num2);
    setResult(`${num1} * ${num2} = ${product}`);
  };

  const handleDivideClick = () => {
    if (Number(num2) === 0) {
      setResult(<span className="error">Cannot divide by zero</span>);
    } else {
      const quotient = Number(num1) / Number(num2);
      setResult(`${num1} / ${num2} = ${quotient}`);
    }
  };

  return (
    <div className="calculator">
      <h2>Calculator</h2>
      <table>
        <tbody>
          <tr>
            <td>
              <label htmlFor="num1">Number 1:</label>
            </td>
            <td>
              <input type="number" id="num1" value={num1} onChange={handleNum1Change} />
            </td>
          </tr>
          <tr>
            <td>
              <label htmlFor="num2">Number 2:</label>
            </td>
            <td>
              <input type="number" id="num2" value={num2} onChange={handleNum2Change} />
            </td>
          </tr>
          <tr>
            <td colSpan="2">
              <button onClick={handleAddClick}>Add (+)</button>
              <button onClick={handleSubtractClick}>Subtract (-)</button>
              <button onClick={handleMultiplyClick}>Multiply (x)</button>
              <button onClick={handleDivideClick}>Divide (/)</button>
            </td>
          </tr>
          <tr>
            <td colSpan="2" className="result">
              Result: {result}
            </td>
          </tr>
        </tbody>
      </table>
    </div>
  );
}
